<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['recaptcha_site_key'] = '';
$config['recaptcha_secret_key'] = '';
$config['recaptcha_lang'] = 'tr';