#FURKAN KARABEY#
#KURULUM
#application->config->database.php 10,11,12 satırları kendinize göre düzenleyiniz
#localhost için bir şey yapmanıza gerek yok phpmyadminden vt isimli veri tabanı oluşturarak vt.sql'i içe aktar yaparak sorunsuz kurulum gerçekleştirebilirsiniz.
#admin girişi için;
#localhost/panel veya siteadi.com/panel 
#kullanıcı adı: furkan
#şire: karabey